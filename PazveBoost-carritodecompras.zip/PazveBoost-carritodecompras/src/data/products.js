export const products = [
    {
        id: 1,
        name: "TP-Link Tapo C200",
        price: "$329.900 COP",
        image: "/images/camara1.png",
    },
        {
        id: 2,
        name: "eufyCam S330",
        price: "$350.000 COP",
        image: "/images/camara2.png",
    },
        {
        id: 3,
        name: "Instalación",
        price: "$300.000 COP",
        image: "/images/instalacion.jpg",
    },
]