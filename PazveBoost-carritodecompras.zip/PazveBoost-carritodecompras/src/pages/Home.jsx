import ShoppingCart from "./carritodecompras/ShoppingCart"

function Home () {
  return (
    <div>
      <ShoppingCart />
    </div>
  );
};


export default Home