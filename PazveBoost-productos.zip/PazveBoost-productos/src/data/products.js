export const products = [
    {
        id: 1,
        name: "TP-Link Tapo C200",
        price: "$329.900 COP",
        image: "/images/camara1.png",
    },
        {
        id: 2,
        name: "eufyCam S330",
        price: "$350.000 COP",
        image: "/images/camara2.png",
    },
        {
        id: 3,
        name: "Reolink Argus 3 Pro",
        price: "$300.000 COP",
        image: "/images/camara3.png",
    },
        {
        id: 4,
        name: "DS-2CD2T86G2-ISU/SL",
        price: "$1,240.522 COP",
        image: "/images/camara4.png",
    },
        {
        id: 5,
        name: "Dahua IPC-HFW2831S-S",
        price: "$500.000 COP",
        image: "/images/camara5.png",
    },
        {
        id: 6,
        name: "DS-2CD2T86G2-ISU/SL",
        price: "$350.000 COP",
        image: "/images/camara6.png",
    },
]