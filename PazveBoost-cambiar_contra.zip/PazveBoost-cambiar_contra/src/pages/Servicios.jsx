
function Header () {
    return (
        <div>
            <button>Inicio</button>
            <button>Nosotros</button>
            <button>Productos</button>
            <button>Servicios</button>
            <button>Contactenos</button>
            <button>Iniciar Sesion</button>
        </div>
    )
}

export default Header