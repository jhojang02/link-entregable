export const products = [
    {
        id: 1,
        name: "Instalación",
        price: "$175.000 COP",
        image: "/images/image 1.png",
    },
        {
        id: 2,
        name: "Soporte Técnico",
        price: "$350.000 COP",
        image: "/images/image 2.png",
    },
        {
        id: 3,
        name: "Automatizacion",
        price: "$300.000 COP",
        image: "/images/image 3.png",
    },
        {
        id: 4,
        name: "Asesorías",
        price: "$1,240.522 COP",
        image: "/images/image 4.png",
    },
        {
        id: 5,
        name: "Soporte a Servisores",
        price: "$500.000 COP",
        image: "/images/image 5.png",
    },
        {
        id: 6,
        name: "Sistema Antirobo",
        price: "$350.000 COP",
        image: "/images/image 6.png",
    },
]