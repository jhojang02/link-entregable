 <?php

    $servername = "localhost";
    $database = "iniciarsesion";
    $username = "root";
    $password = "";
 ?>